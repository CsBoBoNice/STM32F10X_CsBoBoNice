#include "CsBoBo_STM32F10X_LIB.h"

int main(void)
{	
	while(1)
	{		

	}
}
