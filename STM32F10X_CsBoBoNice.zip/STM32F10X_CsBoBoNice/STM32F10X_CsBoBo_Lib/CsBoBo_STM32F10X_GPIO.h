#ifndef _CSBOBO_STM32F10X_GPIO_H_
#define _CSBOBO_STM32F10X_GPIO_H_

#include "stm32f10x.h"

void GPIO_Common_Init(GPIO_TypeDef* GPIOx,u16 gpio_pin,GPIOMode_TypeDef GPIO_Mode);
#endif



