#ifndef _CSBOBO_STM32F10X_NVIC_H
#define _CSBOBO_STM32F10X_NVIC_H 			   
#include "stm32f10x.h"

void NVIC_Configuration(void);

#endif

