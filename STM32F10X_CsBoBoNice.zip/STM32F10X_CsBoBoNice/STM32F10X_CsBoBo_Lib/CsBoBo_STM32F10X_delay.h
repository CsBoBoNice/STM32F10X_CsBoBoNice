#ifndef _CSBOBO_STM32F10X_DELAY_H
#define _CSBOBO_STM32F10X_DELAY_H 			   
#include "stm32f10x.h"

void delay_us(u32 nTimer);
void delay_ms(u32 nTimer);
#endif





























